#脚本开始
MODDIR=${0%/*}
# 日志文件路径
LOG_FILE="${MODDIR}/script.log"

# 删除旧的日志文件
if [ -f "$LOG_FILE" ]; then
    rm -f "$LOG_FILE"
fi

# 创建新的空日志文件
touch "$LOG_FILE"

# 时间格式化函数
function formatted_date() {
    echo $(date '+%Y-%m-%d %H:%M:%S.%3N')
}

echo "$(formatted_date):  service.sh运行" >> "$LOG_FILE"

sed -i '6,7d' $MODDIR/module.prop
echo "description=service.sh运行:检查status节点" >>$MODDIR/module.prop

read status <$MODDIR/config/PATH_status
if [ -e $status ];then
    echo "$(formatted_date):  service.sh运行，$status存在" >> "$LOG_FILE"
    sleep 1
else
    sed -i '6,7d' $MODDIR/module.prop
    echo "description=service.sh运行:挂载debugfs" >>$MODDIR/module.prop
    echo "$(formatted_date):  service.sh运行，挂载debugfs" >> "$LOG_FILE"
    /bin/mount -t debugfs none /sys/kernel/debug/
fi
sleep 10
echo "$(formatted_date):  service.sh运行，main.sh" >> "$LOG_FILE"
sed -i '6,7d' $MODDIR/module.prop
echo "description=service.sh运行:即将运行主函数" >>$MODDIR/module.prop
/bin/sh $MODDIR/main.sh
