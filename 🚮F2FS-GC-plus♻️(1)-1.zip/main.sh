MODDIR=${0%/*}  
LOG_FILE="${MODDIR}/script.log"  
DEBUG=0  # 日志级别控制：0=关闭详细日志，1=开启调试  

# 初始化全局常量  
KB_TO_MB=1000  
MB_TO_GB=1000  
MAX_LIST_ELEMENTS=360  
SLEEP_DURATION_FILE="${MODDIR}/config/sleep_time.txt"  

# 校验配置文件存在  
for file in "$MODDIR/config/PATH_userdata" "$MODDIR/config/PATH_status" "$MODDIR/config/PATH_fs_type"; do  
    if [ ! -f "$file" ]; then  
        echo "$(formatted_date): 配置文件 $file 缺失，脚本终止" >> "$LOG_FILE"  
        exit 1  
    fi  
done  

# 校验 bc 命令存在  
if ! command -v bc &> /dev/null; then  
    echo "$(formatted_date): bc 命令未安装，无法进行浮点运算，脚本终止" >> "$LOG_FILE"  
    exit 1  
fi  

if [ ! -f "$LOG_FILE" ]; then  
    touch "$LOG_FILE"  
fi  

function formatted_date() {  
    echo $(date '+%Y-%m-%d %H:%M:%S.%3N')  
}  

trap 'echo "$(formatted_date): \"${last_command}\" 命令在第${LINENO}行运行时出错" >> "$LOG_FILE"' ERR  

function tf_var() {  
    local val1=${1:-0}  
    local val2=${2:-0}  
    data_cp=$((val2 * 10))  
    if [ $val1 -gt $data_cp ]; then  
        out="↓"  
    elif [ $val1 -lt $data_cp ]; then  
        out="↑"  
    else  
        out="–"  
    fi  
    echo "$out"  
}  

function update_list() {  
    local new_data=$(( ${2:-0} * 10 ))  
    local out="$new_data $1"  
    local element_count=$(echo "$out" | wc -w)  # 更简洁的元素计数  
    if [ $element_count -gt $MAX_LIST_ELEMENTS ]; then  
        out=$(echo "$out" | tr ' ' '\n' | tail -n $MAX_LIST_ELEMENTS | tr '\n' ' ')  
    fi  
    echo "$out"  
}  

function tf_avg() {  
    local temp_All=0  
    for num in $1; do  
        ((temp_All += num))  
    done  
    sample_timer=${sample_timer:-1}  
    echo $(( temp_All / sample_timer ))  
}  

function Level_Read() {  
    if [ $BDF -lt 60 ]; then  
        Lv_R="掉速"  
    elif [ $BDF -lt 70 ]; then  
        Lv_R="偏低"  
    elif [ $BDF -lt 80 ]; then  
        Lv_R="正常"  
    elif [ $BDF -lt 90 ]; then  
        Lv_R="高速"  
    else  
        Lv_R="极高"  
    fi  
}  

function Level_Write(){
    Lv_W="NULL"

    if [ $Level_free -lt "10" ]; then
        Lv_W="掉速"
    elif [ $Level_free -lt "70" ]; then
        Lv_W="偏低"
    elif [ $Level_free -lt "150" ]; then
        Lv_W="正常"
    elif [ $Level_free -lt "300" ]; then
        Lv_W="高速"
    else
        Lv_W="满速"
    fi
}

function GC_MODE_C() {  
    if [ $Level_free -lt 70 ]; then  
        SEFF=2  
    elif [ $Level_free -lt 200 ]; then  
        SEFF=3  
    elif [ $Level_free -lt 300 ]; then  
        SEFF=4  
    elif [ $BDF -lt 65 ]; then  
        SEFF=1  
    elif [ $BDF -lt 75 ]; then  
        SEFF=2  
    elif [ $BDF -lt 85 ]; then  
        SEFF=3  
    elif [ $BDF -lt 95 ]; then  
        SEFF=4  
    else  
        SEFF=5  
    fi  

    case $SEFF in  
        1)  GC_MODE=1; GC_UST=30; MODE="紧急GC" ;;  
        2)  GC_MODE=2; GC_UST=50; MODE="增强GC" ;;  
        3)  GC_MODE=3; GC_UST=80; MODE="普通GC" ;;  
        4)  GC_MODE=4; GC_UST=100; MODE="监控模式" ;;  
        5)  GC_MODE=0; GC_UST=5; MODE="系统GC" ;;  
    esac  
}  

function lock_val() {  
    local val=$1  
    local file=$2  
    read temp <"$file"  
    if [ "$val" != "$temp" ]; then  
        chmod 0644 "$file"  
        echo "$val" >"$file"  
        chmod 0444 "$file"  
    fi  
}  

function calculate_free_space(){
    Free=$(cat $status | grep -A130 "$userdata" | grep -m 1 -w "Free" | awk '{print $3}' | tr -cd "[0-9]")
    Level_free=$Free
    echo "剩余空间: $Free" >> "$LOG_FILE"
    echo "上一次剩余空间: $Free_A" >> "$LOG_FILE"
    Free_vd=$(tf_var $Free_A $Free)
    echo "Free_vd: $Free_vd" >> "$LOG_FILE"
    Free_L=$(update_list "$Free_L" $Free)
    Free_A=$(tf_avg "$Free_L")
    if [ "$Free" -ge "512" ]; then
        tmp_num=$(echo "scale=1; $Free/512" | bc)
        Free=""$tmp_num" GB"
    else
        tmp_num=$(echo "scale=0; $Free*2" | bc)
        Free=""$tmp_num" MB"
    fi

    main_area=$(cat $status | grep -A130 "$userdata" | grep -m 1 -w "Main area" | awk '{print $3}' | tr -cd "[0-9]")
    Level_free=$(echo "scale=0; $Level_free*1000/$main_area" | bc)
}
function calculate_dirty_block(){
    DB=$(cat $status | grep -A130 "$userdata" | grep -m 1 -w "Dirty" | awk '{print $3}' | tr -cd "[0-9]")
    echo "脏块数量: $DB" >> "$LOG_FILE"
    echo "上一次脏块数量: $DB_A" >> "$LOG_FILE" 
    DB_vd=$(tf_var $DB_A $DB)
    echo "DB_vd: $DB_vd" >> "$LOG_FILE"
    DB_L=$(update_list "$DB_L" $DB)
    DB_A=$(tf_avg "$DB_L")
    if [ "$DB" -ge "512" ]; then
        tmp_num=$(echo "scale=1; $DB/512" | bc)
        DB=""$tmp_num" GB"
        DB_real=$(printf "%.0f" "$tmp_num")
        DB_real=$(echo "$DB_real * 1000" | bc)
    else
        tmp_num=$(echo "scale=0; $DB*2" | bc)
        DB=""$tmp_num" MB"
        DB_real=$(printf "%.0f" "$tmp_num")
    fi

}  

function calculate_gc_speed() {  
    local status_content=$1  
    local gc_calld=$(echo "$status_content" | grep -A130 "$userdata" | grep -w "GC calls" | awk '{print $3}' | tr -cd "[0-9]")  
    gc_calld=${gc_calld:-0}  
    gc_call=${gc_call:-0}  

    gc_call_diff=$((gc_calld >= gc_call ? gc_calld - gc_call : 0))  
    gc_call=$gc_calld  

    if echo "$gc_call_diff" | grep -qE '^[0-9]+$' && [ "$gc_call_diff" -gt 0 ]; then  
        list="$gc_call_diff $list"  
    else  
        if [ $DEBUG -eq 1 ]; then  
            echo "$(formatted_date): GC调用差值无效（$gc_call_diff），跳过记录" >> "$LOG_FILE"  
        fi  
        list=""  
    fi  

    local elements=$(echo "$list" | tr ' ' '\n' | tail -n 60 | tr '\n' ' ')  
    list="$elements"  

    gc_calls=0  
    for num in $list; do  
        if echo "$num" | grep -qE '^[0-9]+$'; then  
            ((gc_calls += num))  
        elif [ $DEBUG -eq 1 ]; then  
            echo "$(formatted_date): 列表中存在非数字值（$num），跳过" >> "$LOG_FILE"  
        fi  
    done  

    sample_timer=${sample_timer:-1}  
    gc_speed_A=$((gc_calls / sample_timer))  
    gc_speed_vd=$(tf_var "$gc_speed_A" "$gc_calls")  

    if ((gc_calls >= 512000)); then  
        tmp_num=$(echo "scale=1; $gc_calls / $KB_TO_MB / $MB_TO_GB" | bc)  
        gc_speed="${tmp_num} GB/小时"  
    elif ((gc_calls >= KB_TO_MB)); then  
        tmp_num=$(echo "scale=0; $gc_calls / $KB_TO_MB" | bc)  
        gc_speed="${tmp_num} MB/小时"  
    else  
        gc_speed="${gc_calls} KB/小时"  
    fi  
}  

export bc=$MODDIR/bin/bc
export sed=$MODDIR/bin/toybox
export awk=$MODDIR/bin/toybox
export tr=$MODDIR/bin/toybox
export grep=$MODDIR/bin/toybox

read userdata <$MODDIR/config/PATH_userdata
read status <$MODDIR/config/PATH_status
read fs_type <$MODDIR/config/PATH_fs_type
read gc_support <$MODDIR/config/gc_supported

read max_memory_clean_data <$MODDIR/config/max_memory_clean_data
read max_disk_clean_data <$MODDIR/config/max_disk_clean_data

max_memory_clean_data=$(expr "$max_memory_clean_data" + 0)
max_disk_clean_data=$(expr "$max_disk_clean_data" + 0)
Free_A=""
DB_A=""
DB_real=0
gc_speed_A=""
sample_timer=1
GC_MODE=0
GC_UST=50
clean_all=0

Lv_R="NULL"  
Lv_W="NULL"  
now_work_tip="普通任务"  
SEFF=5  
gc_call=$(cat $status | grep -A130 "$userdata" | grep -m 1 -w "GC calls" | awk '{print $3}' | tr -cd "[0-9]")


while true; do  
    echo "$(formatted_date): 脚本开始循环运行（当前任务: $now_work_tip）" >> "$LOG_FILE"  

    # 仅读取一次 status 内容  
    status_content=$(cat "$status")  

    lock_val "$GC_MODE" "/sys/fs/$fs_type/$userdata/gc_urgent"  
    lock_val "$GC_UST" "/sys/fs/$fs_type/$userdata/gc_urgent_sleep_time"  

    calculate_free_space "$status_content"  
    calculate_dirty_block "$status_content"  
    calculate_gc_speed "$status_content"  

    BDF=$(echo "$status_content" | grep -A130 "$userdata" | grep -w "BDF" | awk '{print $2}' | tr -cd "[0-9]")  
    BDF=${BDF:-0}  
    BDF=$(expr "$BDF" + 0)  

    Level_Read  
    Level_Write  

    if [ $DB_real -ge $max_memory_clean_data ]; then  
        clean_all=1  
        echo "$(formatted_date): 脏块超过 $max_memory_clean_data KB 阈值，开始一次性回收所有碎片" >> "$LOG_FILE"  
    fi  
    if [ $BDF -lt $max_disk_clean_data ]; then  
        clean_all=1  
        echo "$(formatted_date): 磁盘效率小于 $max_disk_clean_data %，开始一次性回收所有碎片" >> "$LOG_FILE"  
    fi  
    if [ $clean_all = 1 ]; then  
        if [ $DB_real -lt 1000 ]; then  
            clean_all=0  
            GC_MODE=0  
            echo "$(formatted_date): 一次性回收所有碎片完成" >> "$LOG_FILE"  
            now_work_tip="一次性彻底GC所有脏块完成，即将进行普通任务"  
            SEFF=5  
        else  
            echo "$(formatted_date): 一次性回收所有碎片中" >> "$LOG_FILE"  
            GC_MODE=1  
            MODE="一次性彻底GC所有脏块中"  
            now_work_tip="一次性彻底GC所有脏块中"  
            SEFF=1  
        fi  
    else  
        GC_MODE_C  
    fi  

    cp_interval=$(cat /sys/fs/$fs_type/$userdata/cp_interval)  
    iostat_enable=$(cat /sys/fs/$fs_type/$userdata/iostat_enable)  
    gc_urgent_sleep_time=$(cat /sys/fs/$fs_type/$userdata/gc_urgent_sleep_time)  
    discard_max_bytes=$(cat /sys/block/sda/queue/discard_max_bytes)  

    sed -i '6,7d' $MODDIR/module.prop  

    if [ -z "${Free// }" ]; then  
        show_log="description=模块运行错误，请检查日志:/data/adb/modules/F2FS-SuperGC/script.log"  
    else  
        show_log="description=剩余空间:$Free $Free_vd   脏块:$DB $DB_vd   处理模式:$MODE   处理速率:$gc_speed $gc_speed_vd   读速: $Lv_R/写速:$Lv_W   磁盘效率:$BDF%   处理等级:$SEFF   F2FS:$cp_interval|$iostat_enable|$gc_urgent_sleep_time|$discard_max_bytes   当前任务:$now_work_tip  自定义配置:$max_disk_clean_data%/$max_memory_clean_data KB   更新日期:$(formatted_date)"  
    fi  

    sleep_duration=$(<"$SLEEP_DURATION_FILE" 2>/dev/null)  # 静默读取，忽略错误  
    if [[ -z "$sleep_duration" ]]; then  
        sleep_duration=180  # 默认睡眠180秒（原逻辑）  
        show_log="description=无法读取 sleep_time.txt，使用默认睡眠时长 180 秒"  
    fi  


    echo "$show_log" >>"$MODDIR/module.prop"  
    echo "$(formatted_date): $show_log" >> "$LOG_FILE"  

    if [ $sample_timer -lt 360 ]; then  
        sample_timer=$((sample_timer + 1))  
    fi  


    echo "$(formatted_date): 脚本睡眠 $sleep_duration 秒" >> "$LOG_FILE"  
    sleep "$sleep_duration"
done  
