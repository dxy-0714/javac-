#安装脚本
touch "$MODDIR/first_run.flag"  # 安装时创建首次运行标记  

function chooseport() {
  # Original idea by chainfire and ianmacd @xda-developers
  [ "$1" ] && local delay=$1 || local delay=3
  local error=false 
  while true; do
    local count=0
    while true; do
      timeout $delay /system/bin/getevent -lqc 1 2>&1 > $TMPDIR/events &
      sleep 0.5; count=$((count + 1))
      if (`grep -q 'KEY_VOLUMEUP *DOWN' $TMPDIR/events`); then
        return 0
      elif (`grep -q 'KEY_VOLUMEDOWN *DOWN' $TMPDIR/events`); then
        return 1
      fi
      [ $count -gt 15 ] && break
    done
    if $error; then
      error=true
      echo "好像未检测到音量键。再试一次"
    fi
  done
}


function get_type(){
	    if [ -e "/proc/fs/f2fs/status" ] ; then
            echo " > FS信息节点: /proc/fs/f2fs/status "
            status="/proc/fs/f2fs/status"
            fs_type="f2fs"
        else
    	    mount -t debugfs none /sys/kernel/debug
    	    /system/bin/mount -t debugfs none /sys/kernel/debug
		    if [ -e "/d/mifs/status" ];then
		        echo " > FS信息节点: /d/mifs/status "
		        status="/d/mifs/status"
		        fs_type="mifs"
		    elif [ -e "/d/f2fs/status" ];then
		        echo " > FS信息节点: /d/f2fs/status "
		        status="/d/f2fs/status"
		        fs_type="f2fs"
            else
                echo " > ERROR！未找到status节点！"
		        sleep 0.2
			    echo " > 取消安装 "
		        abort
		    fi
        fi
        echo "$status" > "$MODPATH/config/PATH_status"
        echo "$fs_type" > "$MODPATH/config/PATH_fs_type"
}

function data_devA(){
	    userdata=$(/bin/df "/data" | grep "/dev" | awk '{print $1}')
        userdata=${userdata##*/}
		if [ -d "/sys/fs/$fs_type/$userdata" ];then
			encryption=$(echo "$userdata" | tr -cd "dm-")
			if [ "$encryption" = "dm-" ];then
				echo " > DATA分区号：$userdata (已加密) "
				echo " > FS接口：/sys/fs/$fs_type/$userdata "
			else
				echo " > DATA分区号：$userdata (未加密) "
				echo " > FS接口：/sys/fs/$fs_type/$userdata "
			fi
		else
			echo " > ERROR！未找到DATA的FS接口！"
			sleep 1
			echo " > 切换到备用查找逻辑B "
			sleep 0.5
			data_devB
		fi
}
	
function data_devB(){
		part_list=$(cat "$status" | grep -B30 -w "Main area" | grep -w "partition info" | awk 'BEGIN{ FS="(" ; RS=")" } NF>1 { print $NF }')
		part_num=$(cat "$status" | grep -w "Main area" | awk '{print $3}')
		num=0
		for i in "$part_num" ; do
		    if [ "$i" -ge "7000" ];then
		        count=0
		        for n in "$part_list" ; do
		            if [ "$count" -ge "$num" ];then
		                userdata="$n"
		                break
		            else
		                count=$(($count + 1))
		            fi
		        done
		    else
		        num=$(($num + 1))
		    fi
		done
		if [ -d "/sys/fs/$fs_type/$userdata" ];then
			encryption=$(echo "$userdata" | tr -cd "dm-")
			if [ "$encryption" = "dm-" ];then
				echo " > DATA分区号：$userdata (已加密) "
				echo " > FS接口：/sys/fs/$fs_type/$userdata "
			else
				echo " > DATA分区号：$userdata (未加密) "
				echo " > FS接口：/sys/fs/$fs_type/$userdata "
			fi
		else
			echo " > ERROR！未找到DATA的FS接口！"
			sleep 0.2
			echo " > 取消安装 "
			abort
		fi
}
	
function get_userdata(){
        userdata=$(getprop dev.mnt.dev.data)
        if [ "$userdata" != "" ];then
	    	if [ -d "/sys/fs/$fs_type/$userdata" ];then
			    encryption=$(echo "$userdata" | tr -cd "dm-")
			    if [ "$encryption" = "dm-" ];then
    				echo " > DATA分区号：$userdata (已加密) "
    				echo " > FS接口：/sys/fs/$fs_type/$userdata "
			    else
				    echo " > DATA分区号：$userdata (未加密) "
				    echo " > FS接口：/sys/fs/$fs_type/$userdata "
			    fi
		    else
			    echo " > ERROR！未找到DATA的FS接口！"
			    sleep 0.5
			    echo " > 切换到备用查找逻辑A "
			    sleep 1
			    data_devA
		    fi
		else
		    echo " > 主逻辑不可用！"
		    sleep 0.5
		    echo " > 切换到备用查找逻辑A "
		    data_devA
		fi
		echo "$userdata" > "$MODPATH/config/PATH_userdata"
}



function check_inf(){
        Free=$(cat "$status" | grep -A130 "$userdata" | grep -m 1 -w "Free" | awk '{print $3}' | tr -cd "[0-9]")
        chk_data "$Free"
		if [ "$Free" -ge "512" ];then
			tmp_num=$(echo "scale=1; $Free/512" | bc)
			Free=""$tmp_num"_GB"
		else
		    tmp_num=$(echo "scale=0; $Free*2" | bc)
		    Free=""$tmp_num"_MB"
		fi
		BDF=$(cat "$status" | grep -A130 "$userdata" | grep -m 1 -w "BDF" | awk '{print $2}' | tr -cd "[0-9]")
		chk_data "$BDF"
        DB=$(cat "$status" | grep -A130 "$userdata" | grep -m 1 -w "Dirty" | awk '{print $3}' | tr -cd "[0-9]")
        chk_data "$DB"
       	if [ "$DB" -ge "512" ];then
	    	tmp_num=$(echo "scale=1; $DB/512" | bc)
		    DB=""$tmp_num"_GB"
	    else
            tmp_num=$(echo "scale=0; $DB*2" | bc)
		    DB=""$tmp_num"_MB"
	    fi
        echo " > 可分配:$Free | Dirty:$DB | 效率:$BDF% "
}
	


#install
ui_print " ------ 支持:Magisk/KSU/APacth"
ui_print " ------ 检测运行环境 "
sleep 1
chmod 0755 $MODPATH/bin/bc
chmod 0755 $MODPATH/bin/toybox
chmod 0755 $MODPATH/main.sh
export bc=$MODPATH/bin/bc
export sed=$MODPATH/bin/toybox
export awk=$MODPATH/bin/toybox
export tr=$MODPATH/bin/toybox
export grep=$MODPATH/bin/toybox
export mount=$MODPATH/bin/toybox
sleep 1



get_type
sleep 0.2
get_userdata
sleep 0.5



ui_print " ------ 安装已完成，请重启！"

if [ -d /data/data/com.coolapk.market ]; then
   ui_print " "
   ui_print "检测到你安装了酷安"
   ui_print "即将跳转到开发者主页(可选)"
   ui_print "  音量+ = 好呀"
   ui_print "  音量– = 不好"
   if chooseport; then
     ui_print "正在跳转....."
     am start -d 'coolmarket://u/37304191' >/dev/null 2>&1
   fi
fi